#!/bin/sh
sudo ln -s hooker.sh /etc/libvirt/hooks/qemu
